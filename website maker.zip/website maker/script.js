console.log('JavaScript Console');
function updateServiceDetails() {
    const serviceData = {
        aadhaar_link: {
            name: "আধার কার্ডের সাথে মোবাইল নাম্বার লিঙ্ক",
            charge: "২০০ টাকা",
            docs: "আধার কার্ড ফটো, মোবাইল নাম্বার, ফিঙ্গারপ্রিন্ট"
        },
        aadhaar_name: {
            name: "আধার কার্ডের নাম সংশোধন",
            charge: "৪০০ টাকা",
            docs: "আধার কার্ড, ভোটার কার্ড, ফিঙ্গারপ্রিন্ট"
        },
        aadhaar_dob: {
            name: "আধার কার্ডে জন্ম তারিখ পরিবর্তন",
            charge: "৪০০ টাকা",
            docs: "আধার কার্ড, জন্ম সার্টিফিকেট, পাসপোর্ট বা অ্যাডমিট কার্ড"
        },
        aadhaar_child: {
            name: "৫ বছরের নিচে বাচ্চার আধার কার্ড",
            charge: "৩০০ টাকা",
            docs: "বাচ্চার পাসপোর্ট সাইজ ফটো, বাবা/মার আধার, জন্ম সনদ, ফিঙ্গারপ্রিন্ট"
        },
        voter_new: {
            name: "নতুন ভোটার কার্ড আবেদন",
            charge: "৮০ টাকা",
            docs: "আধার কার্ড, পাসপোর্ট সাইজ ফটো, পরিবারের একজনের ভোটার কার্ড"
        },
        voter_link: {
            name: "ভোটার কার্ডের সাথে আধার/মোবাইল লিঙ্ক",
            charge: "৫০ টাকা",
            docs: "আধার কার্ড, ভোটার কার্ড, মোবাইল নম্বর, OTP"
        },
        voter_update: {
            name: "ভোটার কার্ডের অন্যান্য সংশোধন",
            charge: "১০০ টাকা",
            docs: "আধার কার্ড, ভোটার কার্ড, সংশোধিত তথ্য"
        },
        pan_new: {
            name: "নতুন প্যান কার্ড আবেদন",
            charge: "১৪০ টাকা",
            docs: "পাসপোর্ট সাইজ ফটো, পিতা/মাতার আধার বা ভোটার কার্ড, আবেদনকারীর আধার"
        },
        pan_lost: {
            name: "হারানো প্যান কার্ড পুনরুদ্ধার",
            charge: "১০০ টাকা (নাম্বার না থাকলে ২০০ টাকা)",
            docs: "আবেদনকারীর আধার, হারানো প্যানের কোনো কপি থাকলে"
        },
        birth_10: {
            name: "১০ বছরের নিচে জন্ম সনদ",
            charge: "২০০০ টাকা",
            docs: "সঠিক নাম, পিতা-মাতার নাম, আধার নম্বর, ঠিকানা"
        },
        birth_above10: {
            name: "১০ বছরের উপরে জন্ম সনদ",
            charge: "৩৫০০ টাকা",
            docs: "সঠিক নাম, পিতা-মাতার নাম, আধার নম্বর, ঠিকানা"
        },
        ration_new: {
            name: "নতুন রেশন কার্ড আবেদন",
            charge: "৮০ টাকা",
            docs: "আধার কার্ড অথবা জন্ম সার্টিফিকেট এবং বাড়ির কাহারো রেশন কার্ড"
        },
        ration_link: {
            name: "রেশন কার্ডের সাথে মোবাইল নাম্বার ও e-KYC",
            charge: "৫০ টাকা",
            docs: "রেশন কার্ড নম্বর, আধার কার্ডের OTP"
        },
        ration_update: {
            name: "রেশন কার্ড সংশোধন (নাম, ঠিকানা, ক্যাটাগরি পরিবর্তন)",
            charge: "১০০ টাকা",
            docs: "প্রয়োজনীয় সমস্ত তথ্য ও সংশোধনের ডকুমেন্ট"
        }
    };

    let selectedService = document.getElementById("serviceSelect").value;
    if (selectedService in serviceData) {
        document.getElementById("serviceName").innerText = serviceData[selectedService].name;
        document.getElementById("serviceCharge").innerText = serviceData[selectedService].charge;
        document.getElementById("requiredDocs").innerText = serviceData[selectedService].docs;
    } else {
        document.getElementById("serviceName").innerText = "-";
        document.getElementById("serviceCharge").innerText = "-";
        document.getElementById("requiredDocs").innerText = "-";
    }
}